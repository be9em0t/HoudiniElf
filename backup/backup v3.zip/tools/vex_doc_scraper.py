import json
import crawl4ai

def scrape_vex_functions_with_crawl4ai(config_path="tools/vex_crawl4ai_config.yaml", output_path="vex_functions_crawl4ai.json"):
    # Create a Crawl4AI crawler instance with the config file
    crawler = crawl4ai.Crawler(config_path)

    # Run the crawler
    crawler.run()

    # After crawling, load the output JSON file
    try:
        with open(output_path, "r") as f:
            functions = json.load(f)
    except FileNotFoundError:
        print(f"Output file {output_path} not found.")
        return

    # Process or print the functions as needed
    print(f"Loaded {len(functions)} functions from Crawl4AI output.")
    for func in functions:
        print(f"Function: {func.get('function_name', 'N/A')}")
        print(f"Signature: {func.get('function_signature', '')}")
        print(f"Description: {func.get('function_description', '')}")
        print("-----")

if __name__ == "__main__":
    scrape_vex_functions_with_crawl4ai()
