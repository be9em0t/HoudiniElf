import json
import re

class VEXVerifier:
    def __init__(self, local_doc_path="vex_functions.json", live_doc_url="https://www.sidefx.com/docs/houdini20.5/vex/index.html"):
        self.local_doc_path = local_doc_path
        self.live_doc_url = live_doc_url
        self.functions = self.load_local_doc()

    def load_local_doc(self):
        try:
            with open(self.local_doc_path, "r") as f:
                return json.load(f)
        except FileNotFoundError:
            print("Local documentation not found.")
            return []

    def is_function_documented(self, func_name):
        for func in self.functions:
            if func["name"] == func_name:
                return True
        return False

    def verify_code(self, code):
        # Extract function calls using regex (simple heuristic)
        pattern = r"([a-zA-Z_][a-zA-Z0-9_]*)\s*\("
        matches = re.findall(pattern, code)
        unique_funcs = set(matches)

        report = []
        for func in unique_funcs:
            if self.is_function_documented(func):
                report.append(f"Function '{func}' is documented.")
            else:
                report.append(f"UNVERIFIED FUNCTION: '{func}' not found in local documentation.")

        return report

if __name__ == "__main__":
    verifier = VEXVerifier()
    sample_code = '''
    int primCount = nprimitives(0);
    vector centroid = primintrinsic(0, "centroid", 0);
    removeprim(0, 0, 1);
    unknownfunc(1, 2);
    '''
    results = verifier.verify_code(sample_code)
    for line in results:
        print(line)
